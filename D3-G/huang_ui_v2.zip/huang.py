"""Run beside the working d3g_bend.py in its existing Python environment."""
import argparse
from pathlib import Path
import time

from d3g_bend import (BendStabilizer, CONNECTIONS, NAMES, bend_scores, cv2, mp,
                      np, open_camera, percentages, python, vision)
from huang_game import Round, POSES
from huang_ui import FollowScreen, instruction


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", help="Actual Arduino/ESP32 COM port; omit for camera preview")
    parser.add_argument("--camera", type=int, default=0)
    args = parser.parse_args()
    model = Path(__file__).resolve().with_name("hand_landmarker.task")
    if not model.is_file():
        alternative = model.with_name("hand_landmarker(1).task")
        if alternative.is_file():
            model = alternative
        else:
            raise FileNotFoundError("Place hand_landmarker.task beside this Python file.")
    options = vision.HandLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_buffer=model.read_bytes()),
        running_mode=vision.RunningMode.VIDEO, num_hands=1,
    )
    screen = FollowScreen()
    title = "SIOR | Robot Hand"
    fullscreen = True
    mode = "follow"
    selected = [mode]
    game = Round()

    def click(event, x, y, flags, userdata):
        if event == cv2.EVENT_LBUTTONUP and 14 <= y <= 54:
            if 678 <= x <= 803:
                selected[0] = "follow"
            elif 813 <= x <= 938:
                selected[0] = "game"

    cap = open_camera(args.camera)
    link = None
    try:
        if args.port:
            import serial
            link = serial.Serial(args.port, 115200, timeout=0, write_timeout=0.3)
            time.sleep(2)  # USB opening may reset the board.
            link.reset_input_buffer()
        opened = closed = None
        stabilizer = BendStabilizer()
        capture = None
        samples = []
        last_timestamp = -1
        last_sent = 0.0
        reply_buffer = ""
        print("Use the SAME hand. O: open calibration; C: fist calibration; ESC: quit.")
        cv2.namedWindow(title, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO | cv2.WINDOW_GUI_NORMAL)
        cv2.resizeWindow(title, 960, 540)
        cv2.moveWindow(title, 0, 0)
        cv2.setWindowProperty(title, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        cv2.setMouseCallback(title, click)
        with vision.HandLandmarker.create_from_options(options) as detector:
            while True:
                ok, frame = cap.read()
                acquired = time.monotonic()
                if not ok:
                    raise RuntimeError("No frame from D3-G camera")
                frame = cv2.flip(frame, 1)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                timestamp = max(time.monotonic_ns() // 1_000_000, last_timestamp + 1)
                last_timestamp = timestamp
                result = detector.detect_for_video(
                    mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb), timestamp)
                raw = measured = values = None
                h, w = frame.shape[:2]
                if result.hand_landmarks and result.hand_world_landmarks:
                    pixels = [(int(p.x * w), int(p.y * h))
                              for p in result.hand_landmarks[0]]
                    for a, b in CONNECTIONS:
                        cv2.line(frame, pixels[a], pixels[b], (0, 220, 0), 2)
                    for p in pixels:
                        cv2.circle(frame, p, 4, (0, 0, 255), -1)
                    try:
                        raw = bend_scores([(p.x, p.y, p.z)
                                           for p in result.hand_world_landmarks[0]])
                    except ValueError:
                        raw = None
                if capture is not None:
                    if raw is None:
                        samples.clear()  # Require consecutive visible-hand frames.
                    else:
                        samples.append(raw.copy())
                    if len(samples) == 30:
                        average = np.median(samples, axis=0)
                        if capture == "open":
                            opened = average
                        else:
                            closed = average
                        capture = None
                        samples.clear()
                if raw is not None and opened is not None and closed is not None and capture is None:
                    try:
                        measured = percentages(raw, opened, closed)
                        values = stabilizer.update(measured, time.monotonic())
                    except ValueError:
                        stabilizer.reset()
                else:
                    stabilizer.reset()
                now = time.monotonic()
                if mode != selected[0]:
                    mode = selected[0]
                    game = Round()
                    last_sent = 0.0
                output = values
                if mode == "game":
                    fingers = None if measured is None else measured[1:]
                    game.tick(now, acquired, fingers)
                    output = POSES.get(game.pose)
                    if game.state == "show":
                        last_sent = 0.0
                if link and now - last_sent >= 0.05:
                    packet = "STOP" if output is None else ",".join(map(str, output))
                    link.write((packet + "\n").encode("ascii"))
                    last_sent = now
                if link and link.in_waiting:
                    reply_buffer += link.read(min(link.in_waiting, 4096)).decode("ascii", errors="replace")
                    while "\n" in reply_buffer:
                        line, reply_buffer = reply_buffer.split("\n", 1)
                        print("Board:", line.strip())
                    reply_buffer = reply_buffer[-4096:]
                hint = instruction(raw, opened, closed, capture, measured)
                if mode == "game" and hint == "ready":
                    hint = {"ready": "game_ready", "result": "game_result"}.get(game.state, "game_throw")
                canvas = screen.render(frame, values, hint, len(samples), stabilizer.state, mode)
                if mode == "game":
                    for row, line in enumerate(game.lines(now)):
                        cv2.putText(canvas, line, (654, 210 + row * 53),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, (53, 60, 23), 2, cv2.LINE_AA)
                cv2.imshow(title, canvas)
                key = cv2.waitKey(1) & 0xFF
                if mode == "game":
                    game.displayed(time.monotonic())
                    if (key == 32 and mode == selected[0] and values is not None
                            and game.state in ("ready", "result")):
                        game.start(time.monotonic())
                    if key in map(ord, "oOcC") and raw is not None:
                        game = Round()
                if key in (ord("f"), ord("F")):
                    fullscreen = not fullscreen
                    cv2.setWindowProperty(title, cv2.WND_PROP_FULLSCREEN,
                                          cv2.WINDOW_FULLSCREEN if fullscreen else cv2.WINDOW_NORMAL)
                if key == 27:
                    break

                if key in (ord("t"), ord("T")):
                    if raw is None or opened is None or closed is None or capture is not None:
                        print("Finish O/C calibration and show your hand first.")
                    elif abs(raw[0] - opened[0]) < 12:
                        print("Thumb angle is too close to the O pose. Try T again.")
                    else:
                        closed[0] = raw[0]
                        stabilizer.reset()
                        print("Thumb 100% saved.")

                if key in (ord("o"), ord("O"), ord("c"), ord("C")):
                    if raw is None:
                        print("Show the same hand before calibration.")
                        continue
                    if key in (ord("o"), ord("O")):
                        capture = "open"
                        opened = closed = None  # Begin a fresh calibration pair.
                    elif opened is not None:
                        capture = "closed"
                        closed = None
                    else:
                        print("Press O with an open hand FIRST.")
                        continue
                    samples.clear()
                    stabilizer.reset()
    finally:
        cap.release()
        cv2.destroyAllWindows()
        if link:
            try:
                link.write(b"STOP\n")
            finally:
                link.close()


if __name__ == "__main__":
    main()
